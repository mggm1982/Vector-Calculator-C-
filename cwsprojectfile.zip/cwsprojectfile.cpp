//code for vector calculator
#include <iostream>// input and output
#include <cmath> // matematical function
#include <iomanip> // setprecision
using namespace std;

const double PI = acos(-1.0); 

class Vector3 {
public: // 
    double v[3]; //array = v[3] (x,y,z)
    Vector3() { // initalise vector to 0
        for (int i = 0; i < 3; i++)
            v[i] = 0;
    }

    void input() {
        for (int i = 0; i < 3; i++)
            cin >> v[i]; 
    }

    void display() {
        cout << "(" << v[0] << ", "
             << v[1] << ", " << v[2] << ")";
    }// (vx,vy,vz)

    double dot(Vector3 b) {
        double ans = 0;
        for (int i = 0; i < 3; i++)
            ans += v[i] * b.v[i];
        return ans;
    } //a.b = axbx +ayby+azbz

    Vector3 cross(Vector3 b) { // cross product c =a x b
        Vector3 c;
        c.v[0] = v[1] * b.v[2] - v[2] * b.v[1];
        c.v[1] = v[2] * b.v[0] - v[0] * b.v[2];
        c.v[2] = v[0] * b.v[1] - v[1] * b.v[0];
        return c;
    }

    double magnitude() {
        return sqrt(dot(*this));
    }// (a.a)^0.5

    Vector3 add(Vector3 b) {
        Vector3 c;
        for (int i = 0; i < 3; i++)
            c.v[i] = v[i] + b.v[i];
        return c;
    }// c =a+b

    Vector3 subtract(Vector3 b) {
        Vector3 c;
        for (int i = 0; i < 3; i++)
            c.v[i] = v[i] - b.v[i];
        return c;
    } //c= a-b

    Vector3 multiply(double k) {
        Vector3 c;
        for (int i = 0; i < 3; i++)
            c.v[i] = v[i] * k;
        return c;
    } //vector c =k vector(a)

    bool isZero() {
        return magnitude() == 0;
    }

    bool parallel(Vector3 b) {
        return cross(b).magnitude() == 0;
    } // a cross b==0 parallel

    bool perpendicular(Vector3 b) {
        return dot(b) == 0;
    } // a.b==0

    Vector3 unit() {
        return multiply(1.0 / magnitude());
    } // unit vector = (a/|a|) in vector form

    Vector3 projectOn(Vector3 b) {
        return b.multiply(dot(b) / b.dot(b));
    } // ((a.b/b.b)*b)

    double distanceTo(Vector3 b) {
        return subtract(b).magnitude();
    } //|a-b|

    Vector3 midpoint(Vector3 b) {
        return add(b).multiply(0.5);
    } //(a+b)/0.5
};

double triple(Vector3 a, Vector3 b, Vector3 c) {
    return a.dot(b.cross(c));
} // a.(bxc) triple product

void findAngle(Vector3 a, Vector3 b) {
    if (a.isZero() || b.isZero()) {
        cout << "Angle is undefined for a zero vector.\n";
    } else {
        double c = a.dot(b) /
                   (a.magnitude() * b.magnitude());
//c= cose=a.b/|a||b|

        if (c > 1) c = 1;
        if (c < -1) c = -1;

        cout << "Angle = " << acos(c) * 180.0 / PI
             << " degrees\n";
    }
}

void directionCosines(Vector3 a) {
    if (a.isZero()) {
        cout << "Direction is undefined for a zero vector.\n";
        return;
    } 

    const char name[3] = {'x', 'y', 'z'};
    for (int i = 0; i < 3; i++) {
        double c = a.v[i] / a.magnitude();
        cout << "cos(" << name[i] << ") = " << c
             << "   angle = " << acos(c) * 180.0 / PI
             << " degrees\n";
    }
}// c =cos e where e is angle
//line 1 P+tD
//line 2 Q+sE
void checkLines(Vector3 P, Vector3 D,
                Vector3 Q, Vector3 E) {
    Vector3 PQ = Q.subtract(P); //Q-P
    Vector3 normal = D.cross(E); //DxE

    if (D.isZero() || E.isZero()) {
        cout << "Invalid line: direction cannot be zero.\n";
    }
    else if (normal.magnitude() == 0) {
        if (PQ.cross(D).magnitude() == 0)//|PQxD|
            cout << "Lines are coincident (same line).\n";
        else
            cout << "Lines are parallel.\n";
    }
    else if (PQ.dot(normal) == 0) { //PQ.normal =0
        cout << "Lines are intersecting.\n";
    }
    else {
        cout << "Lines are skew.\n";
    }
}
//line 1 P+tD
//line 2 Q+sE
void distanceBetweenLines(Vector3 P, Vector3 D,
                          Vector3 Q, Vector3 E) {
    if (D.isZero() || E.isZero()) {
        cout << "Invalid line: direction cannot be zero.\n";
        return;
    }

    Vector3 PQ = Q.subtract(P);
    Vector3 normal = D.cross(E);

    if (normal.magnitude() == 0) { //line are parallel or coincident
        cout << "Distance = "
             << PQ.cross(D).magnitude() / D.magnitude() //| PQ xD|/|D|
             << "\n";
    } else {// LINE must be skew or intersecting
        cout << "Distance = "
             << fabs(PQ.dot(normal)) / normal.magnitude()// |PQ .normal|/|normal|
             << "\n";
    }
}
// p is point, A is point on line and D is direction vector
void distancePointLine(Vector3 P, Vector3 A, Vector3 D) {
    if (D.isZero()) {
        cout << "Invalid line: direction cannot be zero.\n";
        return;
    }

    Vector3 AP = P.subtract(A);
    cout << "Distance = "
         << AP.cross(D).magnitude() / D.magnitude() //|APxD|/|D|
         << "\n";
}

void readTwo(Vector3 &A, Vector3 &B) {
    cout << "Enter vector A (x y z): ";
    A.input();
    cout << "Enter vector B (x y z): ";
    B.input();
}

int main() {
    cout << fixed << setprecision(3);//iomanip

    Vector3 A, B, C;
    int choice;

    do {
        cout << "\n===== VECTOR CALCULATOR =====\n";
        cout << "--- Basic ---\n";
        cout << " 1. Magnitude of a vector\n";
        cout << " 2. Addition of vectors\n";
        cout << " 3. Subtraction of vectors\n";
        cout << " 4. Dot product\n";
        cout << " 5. Cross product\n";
        cout << " 6. Check parallel vectors\n";
        cout << " 7. Check perpendicular vectors\n";
        cout << " 8. Angle between vectors\n";
        cout << " 9. Scalar multiplication\n";
        cout << "10. Area of parallelogram\n";
        cout << "11. Volume of parallelepiped\n";
        cout << "12. Scalar triple product\n";
        cout << "13. Check relationship between two lines\n";
        cout << "--- More operations ---\n";
        cout << "14. Unit vector\n";
        cout << "15. Projection of A onto B\n";
        cout << "16. Distance between two points\n";
        cout << "17. Midpoint of two points\n";
        cout << "18. Area of triangle\n";
        cout << "19. Direction cosines and angles\n";
        cout << "20. Vector triple product A x (B x C)\n";
        cout << "21. Check coplanar vectors\n";
        cout << "22. Distance from a point to a line\n";
        cout << "23. Shortest distance between two lines\n";
        cout << " 0. Exit\n";

        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter x, y, z: ";
            A.input();
            cout << "Magnitude = " << A.magnitude() << "\n";
        }
        else if (choice == 2) {
            readTwo(A, B);

            C = A.add(B);
            cout << "A + B = ";
            C.display();
            cout << "\n";
        }
        else if (choice == 3) {
            readTwo(A, B);

            C = A.subtract(B);
            cout << "A - B = ";
            C.display();
            cout << "\n";
        }
        else if (choice == 4) {
            readTwo(A, B);

            cout << "Dot product = " << A.dot(B) << "\n";
        }
        else if (choice == 5) {
            readTwo(A, B);

            C = A.cross(B);
            cout << "Cross product = ";
            C.display();
            cout << "\n";
        }
        else if (choice == 6 || choice == 7) {
            readTwo(A, B);

            if (A.isZero() || B.isZero()) {
                cout << "Use two non-zero vectors.\n";
            }
            else if (choice == 6) {
                if (A.parallel(B))
                    cout << "Vectors are parallel.\n";
                else
                    cout << "Vectors are not parallel.\n";
            }
            else {
                if (A.perpendicular(B))
                    cout << "Vectors are perpendicular.\n";
                else
                    cout << "Vectors are not perpendicular.\n";
            }
        }
        else if (choice == 8) {
            readTwo(A, B);

            findAngle(A, B);
        }
        else if (choice == 9) {
            double k;
            cout << "Enter vector A (x y z): ";
            A.input();
            cout << "Enter scalar k: ";
            cin >> k;

            C = A.multiply(k);
            cout << "kA = ";
            C.display();
            cout << "\n";
        }
        else if (choice == 10) {
            readTwo(A, B);

            cout << "Area = |A x B| = "
                 << A.cross(B).magnitude() << "\n";
        }
        else if (choice == 11 || choice == 12) {
            readTwo(A, B);
            cout << "Enter vector C (x y z): ";
            C.input();

            double value = triple(A, B, C);

            if (choice == 11)
                cout << "Volume  = " << fabs(value) << "\n";
            else
                cout << "Scalar triple product = "// (axb).c
                     << value << "\n";
        }
        else if (choice == 13) {
            Vector3 P, D, Q, E;
        // P+tD
        //Q+sE
            cout << "Line 1: Enter point P (x y z): ";
            P.input();
            cout << "Enter direction D (x y z): ";
            D.input();

            cout << "Line 2: Enter point Q (x y z): ";
            Q.input();
            cout << "Enter direction E (x y z): ";
            E.input();

            checkLines(P, D, Q, E);
        }
        else if (choice == 14) {
            cout << "Enter vector A (x y z): ";
            A.input();

            if (A.isZero()) {
                cout << "Unit vector is undefined for a zero vector.\n";
            } else {
                C = A.unit();
                cout << "Unit vector = ";
                C.display();
                cout << "\n";
            }
        }
        else if (choice == 15) {
            readTwo(A, B);

            if (B.isZero()) {
                cout << "Cannot project onto a zero vector.\n";
            } else {
                C = A.projectOn(B);
                cout << "Vector projection = ";
                C.display();
                cout << "\n";
                cout << "Scalar projection = "
                     << A.dot(B) / B.magnitude() << "\n";// (a.b)/|b|
            }
        }
        else if (choice == 16) {
            cout << "Enter point A (x y z): ";
            A.input();
            cout << "Enter point B (x y z): ";
            B.input();

            cout << "Distance = " << A.distanceTo(B) << "\n";
        }
        else if (choice == 17) {
            cout << "Enter point A (x y z): ";
            A.input();
            cout << "Enter point B (x y z): ";
            B.input();

            C = A.midpoint(B); 
            cout << "Midpoint = ";
            C.display();
            cout << "\n";// (a+b)0.5
        }
        else if (choice == 18) {
            cout << "Enter point A (x y z): ";
            A.input();
            cout << "Enter point B (x y z): ";
            B.input();
            cout << "Enter point C (x y z): ";
            C.input();

            Vector3 AB = B.subtract(A);
            Vector3 AC = C.subtract(A);
            cout << "Area of triangle = "
                 << 0.5 * AB.cross(AC).magnitude() << "\n";
        } //0.5(ABxAC)
        else if (choice == 19) {
            cout << "Enter vector A (x y z): ";
            A.input();

            directionCosines(A);
        }
        else if (choice == 20) {
            readTwo(A, B);
            cout << "Enter vector C (x y z): ";
            C.input();

            Vector3 R = A.cross(B.cross(C));
            cout << "A x (B x C) = ";
            R.display();
            cout << "\n";
        }
        else if (choice == 21) {
            readTwo(A, B);
            cout << "Enter vector C (x y z): ";
            C.input();

            if (triple(A, B, C) == 0) // STP==0 planar vector
                cout << "Vectors are coplanar.\n";
            else
                cout << "Vectors are not coplanar.\n";
        }
        else if (choice == 22) {
            Vector3 P, D; 
//line A+tD
            
            cout << "Enter the point P (x y z): ";
            P.input();
            cout << "Enter a point on the line (x y z): ";
            A.input();
            cout << "Enter direction of the line (x y z): ";
            D.input();

            distancePointLine(P, A, D);
        }
        else if (choice == 23) {
            Vector3 P, D, Q, E;

            cout << "Line 1: Enter point P (x y z): ";
            P.input();
            cout << "Enter direction D (x y z): ";
            D.input();

            cout << "Line 2: Enter point Q (x y z): ";
            Q.input();
            cout << "Enter direction E (x y z): ";
            E.input();

            distanceBetweenLines(P, D, Q, E);
        }
        else if (choice == 0) {
            cout << "Thank you for using Vector Calculator!\n";
        }
        else {
            cout << "Invalid choice! Try again.\n";
        }

    } while (choice != 0);

    return 0;
}